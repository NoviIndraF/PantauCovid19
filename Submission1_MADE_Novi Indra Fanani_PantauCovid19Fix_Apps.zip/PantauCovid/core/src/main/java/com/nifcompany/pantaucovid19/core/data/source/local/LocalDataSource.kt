package com.nifcompany.pantaucovid19.core.data.source.local

import com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity
import com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity
import com.nifcompany.pantaucovid19.core.data.source.local.room.CovidDao

import kotlinx.coroutines.flow.Flow

class LocalDataSource(private val covidDao: com.nifcompany.pantaucovid19.core.data.source.local.room.CovidDao) {

    companion object {
        private var instance: com.nifcompany.pantaucovid19.core.data.source.local.LocalDataSource? = null

        fun getInstance(covidDao: com.nifcompany.pantaucovid19.core.data.source.local.room.CovidDao): com.nifcompany.pantaucovid19.core.data.source.local.LocalDataSource =
            com.nifcompany.pantaucovid19.core.data.source.local.LocalDataSource.Companion.instance
                ?: synchronized(this) {
                com.nifcompany.pantaucovid19.core.data.source.local.LocalDataSource.Companion.instance
                    ?: com.nifcompany.pantaucovid19.core.data.source.local.LocalDataSource(covidDao)
            }
    }

    fun getDataIndonesia(): Flow<com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity> = covidDao.getDataIndonesia()

    fun getDataProvince(): Flow<List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>> = covidDao.getDataProvince()

    fun getSearchProvince(search: String): Flow<List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>> = covidDao.getSearchProvince(search)

    fun getSaveDataProvince(): Flow<List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>> = covidDao.getSaveDataProvince()

    fun insertDataIndonesia(indonesia: com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity) = covidDao.insertDataIndonesia(indonesia)

    fun insertDataProvince(province: List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>) = covidDao.insertDataProvince(province)


    fun setSaveDataProvince(province: com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity, newState: Boolean) {
        province.isSave = newState
        covidDao.updateSaveDataProvince(province)
    }
}