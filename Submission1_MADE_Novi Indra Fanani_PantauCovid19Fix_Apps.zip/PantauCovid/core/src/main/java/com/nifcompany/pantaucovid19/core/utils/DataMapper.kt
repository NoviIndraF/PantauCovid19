package com.nifcompany.pantaucovid19.core.utils

import android.util.Log
import com.nifcompany.pantaucovid19.core.domain.model.Province
import com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity
import com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity
import com.nifcompany.pantaucovid19.core.data.source.remote.response.IndonesiaResponse.IndonesiaDetailResponse
import com.nifcompany.pantaucovid19.core.data.source.remote.response.ProvinceResponse.ProvinceDetailResponse

object DataMapper {
    fun mapResponsesToEntitiesProvince(input: List<ProvinceDetailResponse>): List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity> {
        val provinceList = ArrayList<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>()
        input.map {
            val province =
                com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity(
                    id = null,
                    date = it.lastDate,
                    name = it.provinsi,
                    lakilaki = it.jenisKelamin.lakiLaki,
                    perempuan = it.jenisKelamin.perempuan,

                    kasus = it.kasus,
                    dirawat = it.dirawat,
                    sembuh = it.sembuh,
                    meninggal = it.meninggal,

                    pPositif = it.penambahan.positif,
                    pSembuh = it.penambahan.sembuh,
                    pMeninggal = it.penambahan.meninggal,

                    kelompok1 = it.kelompokUmur.jsonMember05,
                    kelompok2 = it.kelompokUmur.jsonMember618,
                    kelompok3 = it.kelompokUmur.jsonMember1930,
                    kelompok4 = it.kelompokUmur.jsonMember3145,
                    kelompok5 = it.kelompokUmur.jsonMember4659,
                    kelompok6 = it.kelompokUmur.jsonMember60,

                    lat = it.lokasi.lat,
                    lon = it.lokasi.lon,

                    isSave = false
                )
            provinceList.add(province)
        }
        Log.e("Data Province RtE", provinceList.toString())
        return provinceList
    }

    fun mapEntitiesToDomainProvince(input: List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>): List<Province> =
        input.map{
                Province(
                    id = it.id!!,
                    date = it.date,
                    name = it.name,
                    lakilaki = it.lakilaki,
                    perempuan = it.perempuan,

                    kasus = it.kasus,
                    dirawat = it.dirawat,
                    sembuh = it.sembuh,
                    meninggal = it.meninggal,

                    pPositif = it.pPositif,
                    pSembuh = it.pSembuh,
                    pMeninggal = it.pMeninggal,

                    kelompok1 = it.kelompok1,
                    kelompok2 = it.kelompok2,
                    kelompok3 = it.kelompok3,
                    kelompok4 = it.kelompok4,
                    kelompok5 = it.kelompok5,
                    kelompok6 = it.kelompok6,

                    lat = it.lat,
                    lon = it.lon,

                    isSave = it.isSave
                )
        }

    fun mapDomainToEntityProvince(input: Province)=
        com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity(
            id = input.id,
            date = input.date,
            name = input.name,
            lakilaki = input.lakilaki,
            perempuan = input.perempuan,

            kasus = input.kasus,
            dirawat = input.dirawat,
            sembuh = input.sembuh,
            meninggal = input.meninggal,

            pPositif = input.pPositif,
            pSembuh = input.pSembuh,
            pMeninggal = input.pMeninggal,

            kelompok1 = input.kelompok1,
            kelompok2 = input.kelompok2,
            kelompok3 = input.kelompok3,
            kelompok4 = input.kelompok4,
            kelompok5 = input.kelompok5,
            kelompok6 = input.kelompok6,

            lat = input.lat,
            lon = input.lon,

            isSave = input.isSave
        )

    fun mapEntitiesToDomainIndonesia(input: com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity): com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity =
        com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity(
            id = input.id,
            date = input.date,

            positif = input.positif,
            dirawat = input.dirawat,
            sembuh = input.sembuh,
            meninggal = input.meninggal,

            pPositif = input.pPositif,
            pDirawat = input.pDirawat,
            pSembuh = input.pSembuh,
            pMeninggal = input.pMeninggal,

            odp = input.odp,
            pdp = input.pdp,
            total_spesimen = input.total_spesimen,
            total_spesimen_negatif = input.total_spesimen_negatif
        )

    fun mapResponsesToEntitiesIndonesia(input: IndonesiaDetailResponse): com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity =
        com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity(
            id = null,
            date = input.penambahan.tanggal,

            positif = input.total.positif,
            dirawat = input.total.dirawat,
            sembuh = input.total.sembuh,
            meninggal = input.total.meninggal,

            pPositif = input.penambahan.positif,
            pDirawat = input.penambahan.dirawat,
            pSembuh = input.penambahan.sembuh,
            pMeninggal = input.penambahan.meninggal,

            odp = input.data.odp,
            pdp = input.data.pdp,
            total_spesimen = input.data.totalSpesimen,
            total_spesimen_negatif = input.data.totalSpesimenNegatif
        )
}