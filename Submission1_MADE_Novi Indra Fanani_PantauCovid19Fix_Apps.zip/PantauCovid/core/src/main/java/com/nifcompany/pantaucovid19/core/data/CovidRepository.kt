package com.nifcompany.pantaucovid19.core.data

import com.dicoding.tourismapp.core.data.source.remote.network.ApiResponse
import com.nifcompany.pantaucovid19.core.domain.model.Province
import com.nifcompany.pantaucovid19.core.domain.repository.ICovidRepository
import com.nifcompany.pantaucovid19.core.data.source.local.LocalDataSource
import com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity
import com.nifcompany.pantaucovid19.core.data.source.remote.RemoteDataSource
import com.nifcompany.pantaucovid19.core.data.source.remote.response.IndonesiaResponse.IndonesiaDetailResponse
import com.nifcompany.pantaucovid19.core.data.source.remote.response.ProvinceResponse.ProvinceDetailResponse
import com.nifcompany.pantaucovid19.core.utils.AppExecutors
import com.nifcompany.pantaucovid19.core.utils.DataMapper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CovidRepository(
    private val remoteDataSource: RemoteDataSource,
    private val localDataSource: com.nifcompany.pantaucovid19.core.data.source.local.LocalDataSource,
    private val appExecutors: AppExecutors
) : ICovidRepository {

    companion object {
        @Volatile
        private var instance: com.nifcompany.pantaucovid19.core.data.CovidRepository? = null

        fun getInstance(
            remoteData: RemoteDataSource,
            localData: com.nifcompany.pantaucovid19.core.data.source.local.LocalDataSource,
            appExecutors: AppExecutors
        ): com.nifcompany.pantaucovid19.core.data.CovidRepository =
            com.nifcompany.pantaucovid19.core.data.CovidRepository.Companion.instance ?: synchronized(this) {
                com.nifcompany.pantaucovid19.core.data.CovidRepository.Companion.instance
                    ?: com.nifcompany.pantaucovid19.core.data.CovidRepository(
                        remoteData,
                        localData,
                        appExecutors
                    )
            }
    }

    override fun getDataIndonesia(): Flow<com.nifcompany.pantaucovid19.core.data.Resource<com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity>> =
        object : com.nifcompany.pantaucovid19.core.data.NetworkBoundResource<com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity, IndonesiaDetailResponse>() {
            override fun loadFromDB(): Flow<com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity> {
                return localDataSource.getDataIndonesia()
            }

            override fun shouldFetch(data: com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity?): Boolean =
                data == null

            override suspend fun createCall(): Flow<ApiResponse<IndonesiaDetailResponse>> =
                remoteDataSource.getDataIndonesia()

            override suspend fun saveCallResult(data: IndonesiaDetailResponse) {
                val tourismList = DataMapper.mapResponsesToEntitiesIndonesia(data)
                localDataSource.insertDataIndonesia(tourismList)
            }
        }.asFlow()


    override fun getDataProvince(): Flow<com.nifcompany.pantaucovid19.core.data.Resource<List<Province>>> =
        object : com.nifcompany.pantaucovid19.core.data.NetworkBoundResource<List<Province>, List<ProvinceDetailResponse>>() {
            override fun loadFromDB(): Flow<List<Province>> {
                return localDataSource.getDataProvince().map { DataMapper.mapEntitiesToDomainProvince(it) }
            }

            override fun shouldFetch(data: List<Province>?): Boolean =
                data == null || data.isEmpty()

            override suspend fun createCall(): Flow<ApiResponse<List<ProvinceDetailResponse>>> =
                remoteDataSource.getDataProvince()

            override suspend fun saveCallResult(data: List<ProvinceDetailResponse>) {
                val tourismList = DataMapper.mapResponsesToEntitiesProvince(data)
                localDataSource.insertDataProvince(tourismList)
            }
        }.asFlow()

    override fun getSearchProvince(search: String): Flow<List<Province>> {

        return localDataSource.getSearchProvince(search).map { DataMapper.mapEntitiesToDomainProvince(it) }
    }

    override fun getSaveDataProvince(): Flow<List<Province>> {

        return localDataSource.getSaveDataProvince().map { DataMapper.mapEntitiesToDomainProvince(it) }
    }


    override fun setSaveDataProvince(province: Province, state: Boolean) {
        val provinceEntity   = DataMapper.mapDomainToEntityProvince(province)
        appExecutors.diskIO().execute { localDataSource.setSaveDataProvince(provinceEntity, state) }
    }
}