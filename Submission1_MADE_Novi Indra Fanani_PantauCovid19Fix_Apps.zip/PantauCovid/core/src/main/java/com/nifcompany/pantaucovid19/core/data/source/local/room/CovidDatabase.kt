package com.nifcompany.pantaucovid19.core.data.source.local.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity
import com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity

@Database(entities = [com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity::class, com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity::class],
            version = 1,
            exportSchema = false)
abstract class CovidDatabase : RoomDatabase() {

    abstract fun covidDao(): com.nifcompany.pantaucovid19.core.data.source.local.room.CovidDao

    companion object {
        @Volatile
        private var INSTANCE: com.nifcompany.pantaucovid19.core.data.source.local.room.CovidDatabase? = null

        fun getInstance(context: Context): com.nifcompany.pantaucovid19.core.data.source.local.room.CovidDatabase =
            com.nifcompany.pantaucovid19.core.data.source.local.room.CovidDatabase.Companion.INSTANCE
                ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    com.nifcompany.pantaucovid19.core.data.source.local.room.CovidDatabase::class.java,
                    "Covid.db"
                ).allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build()
                com.nifcompany.pantaucovid19.core.data.source.local.room.CovidDatabase.Companion.INSTANCE = instance
                instance
            }
    }
}