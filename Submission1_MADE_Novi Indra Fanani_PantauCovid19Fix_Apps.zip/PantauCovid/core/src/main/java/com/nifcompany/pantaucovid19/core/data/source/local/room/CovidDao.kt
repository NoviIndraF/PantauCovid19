package com.nifcompany.pantaucovid19.core.data.source.local.room

import androidx.room.*
import com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity
import com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CovidDao {
    @Query("SELECT * FROM dataIndonesia")
    fun getDataIndonesia(): Flow<com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity>

    @Query("SELECT * FROM dataProvinsi ORDER BY name ASC")
    fun getDataProvince(): Flow<List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>>

    @Query("SELECT * FROM dataProvinsi WHERE name LIKE :search || '%' ORDER BY name ASC")
    fun getSearchProvince(search: String?): Flow<List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>>

    @Query("SELECT * FROM dataProvinsi where isSave = 1 ORDER BY name ASC")
    fun getSaveDataProvince(): Flow<List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
     fun insertDataIndonesia(indonesiaEntity: com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
     fun insertDataProvince(provinceEntity: List<com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity>)

    @Update
    fun updateSaveDataProvince(province: com.nifcompany.pantaucovid19.core.data.source.local.entity.ProvinceEntity)
}