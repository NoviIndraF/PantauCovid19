package com.nifcompany.pantaucovid19.core.domain.usecase

import com.nifcompany.pantaucovid19.core.domain.model.Province
import com.nifcompany.pantaucovid19.core.data.Resource
import com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity

import kotlinx.coroutines.flow.Flow

interface CovidUseCase {

    fun getDataIndonesia(): Flow<com.nifcompany.pantaucovid19.core.data.Resource<com.nifcompany.pantaucovid19.core.data.source.local.entity.IndonesiaEntity>>

    fun getDataProvince(): Flow<com.nifcompany.pantaucovid19.core.data.Resource<List<Province>>>

    fun getSearchProvince(search: String): Flow<List<Province>>

    fun getSaveDataProvince(): Flow<List<Province>>

    fun setSaveDataProvince(province: Province, state: Boolean)
}